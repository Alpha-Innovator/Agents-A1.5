# Agents-A1.5 local deployment examples

此包包含三份原始启动脚本及本地接入示例，不包含模型权重、驱动、运行时或工具实现。不会自动安装软件、下载模型或向外部服务发送任务。

## Files

- `original/`: the three supplied launcher scripts, unchanged.
- `examples/llama.sh`: local GGUF paths and a loopback-only service on port 8080.
- `examples/vllm.sh`, `examples/sglang.sh`: the supplied options, adapted to a local model directory and port 8080. The original 262144 context length may require substantial memory; it is not a minimum-device promise.
- `examples/ascend.sh`, `examples/rocm.sh`: conditional integration templates, not model-specific validated hardware configurations.
- `examples/claude-code.sh`: an example for a local backend exposing Anthropic-compatible `/v1/messages`. The llama.cpp server supports this endpoint; tool calls require `--jinja`. Compatibility depends on the installed version and chat template.
- `examples/tools-request.json`: an API request shape declaring the three recorded tools. It is not a complete agent harness.

## Before running

1. Prepare the Agents-A1.5 weights and any required GGUF/mmproj files from an authorized source. The scripts do not establish that the named model repository is public.
2. Install a compatible runtime and hardware drivers. Replace `/path/to/...` in the relevant example. `llama-server`, `vllm` or `sglang` must already be available.
3. Inspect the commands and use `bash examples/<runtime>.sh`. These templates have not been executed on the target hardware as part of this showcase.
4. Use `http://127.0.0.1:8080/v1/models` to inspect the actual served model ID. The llama.cpp example preserves `Agents-A1.5` as its alias; adapt client model IDs to your other runtime's response.

## Tools and harnesses

The recorded tool names are `google_search`, `read_page`, and `PythonInterpreter`. A harness must register their schemas, receive model tool calls, run the selected implementation and return the results. You still need to supply a search provider, a page reader and a restricted local Python execution environment. No provider credentials are included.

The Claude Code example routes model requests to the local Messages endpoint and disables nonessential traffic. `local-dev` is a dummy token for a local server without authentication; replace it if your local server requires authentication. This is a configuration example, not a supplied coding-task result. Do not treat a Chat Completions-only endpoint as a Messages-compatible endpoint.

## Data boundary

Local inference avoids sending model prompts to a hosted model API. That does not automatically make every tool offline: search providers receive queries, and page readers contact target sites. For fully offline work, prepare weights/dependencies first, use local tools, and disable external services, plugins and telemetry as appropriate. Inspect actual network traffic and enforce the intended boundary in your environment.

## Framework references

- https://github.com/ggml-org/llama.cpp
- https://github.com/ggml-org/llama.cpp/blob/master/tools/server/README.md
- https://docs.vllm.ai/en/stable/getting_started/installation/
- https://docs.vllm.ai/projects/ascend/en/main/getting_started/installation.html
- https://code.claude.com/docs/en/env-vars

本次提供的资料不足以确认 NPU / AMD 实测支持、最低内存或 tokens/s。展示没有沿用旧页面中的速度与内存占位数字。
