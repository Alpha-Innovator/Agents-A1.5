#!/usr/bin/env bash
set -euo pipefail
# Compatible vLLM Ascend / CANN environment required
# Model-specific hardware validation is still required.
export MODEL_DIR="/path/to/Agents-A1.5"

vllm serve "$MODEL_DIR" \
  --served-model-name Agents-A1.5 \
  --enable-auto-tool-choice \
  --tool-call-parser qwen3_coder \
  --reasoning-parser qwen3 \
  --host 127.0.0.1 --port 8080
