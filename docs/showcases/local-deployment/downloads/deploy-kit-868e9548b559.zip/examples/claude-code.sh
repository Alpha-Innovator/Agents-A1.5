#!/usr/bin/env bash
# Example: llama-server with /v1/messages and --jinja
ANTHROPIC_BASE_URL=http://127.0.0.1:8080 \
ANTHROPIC_MODEL=Agents-A1.5 \
ANTHROPIC_AUTH_TOKEN=local-dev \
CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC=1 \
claude
