#!/usr/bin/env bash
set -euo pipefail
export GGUF_DIR="/path/to/Agents-A1.5-gguf-Q4_K_M"

llama-server \
  -m "$GGUF_DIR/Agents-A1.5-Q4_K_M.gguf" \
  --mmproj "$GGUF_DIR/Agents-A1.5-mmproj.gguf" \
  --alias Agents-A1.5 \
  --jinja \
  --host 127.0.0.1 --port 8080
