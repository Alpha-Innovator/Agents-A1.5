#!/usr/bin/env bash
set -euo pipefail
export MODEL_DIR="/path/to/Agents-A1.5"

sglang serve --model-path "$MODEL_DIR" \
    --context-length 262144 \
    --reasoning-parser qwen3 \
    --tool-call-parser qwen3_coder \
    --speculative-algorithm EAGLE \
    --speculative-num-steps 3 \
    --speculative-eagle-topk 1 \
    --speculative-num-draft-tokens 4 \
    --mamba-radix-cache-strategy extra_buffer \
    --mem-fraction-static 0.8 \
  --host 127.0.0.1 --port 8080
