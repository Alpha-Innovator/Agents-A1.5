#!/usr/bin/env bash
set -euo pipefail
export MODEL_DIR="/path/to/Agents-A1.5"

vllm serve "$MODEL_DIR" \
  --trust-remote-code \
  --max-model-len 262144 \
  --tensor-parallel-size 1 \
  --enable-auto-tool-choice \
  --tool-call-parser qwen3_coder \
  --reasoning-parser qwen3 \
  --mm-encoder-tp-mode data \
  --speculative-config '{"method":"mtp","num_speculative_tokens":3,"moe_backend":"triton"}' \
  --host 127.0.0.1 --port 8080
