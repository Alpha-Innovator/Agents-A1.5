sglang serve --model-path InternAgents/Agents-A1.5 \
    --context-length 262144 \
    --reasoning-parser qwen3 \
    --tool-call-parser qwen3_coder \
    --speculative-algorithm EAGLE \
    --speculative-num-steps 3 \
    --speculative-eagle-topk 1 \
    --speculative-num-draft-tokens 4 \
    --mamba-radix-cache-strategy extra_buffer \
    --mem-fraction-static 0.8 