vllm serve InternAgents/Agents-A1.5 \
  --trust-remote-code \
  --max-model-len 262144 \
  --tensor-parallel-size 1 \
  --enable-auto-tool-choice \
  --tool-call-parser qwen3_coder \
  --reasoning-parser qwen3 \
  --mm-encoder-tp-mode data \
  --speculative-config '{"method":"mtp","num_speculative_tokens":3,"moe_backend":"triton"}'