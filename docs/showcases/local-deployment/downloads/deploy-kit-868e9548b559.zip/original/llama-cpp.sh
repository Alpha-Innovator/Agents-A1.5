/app/llama-server \
  -m /PATH/TO/Agents-A1.5-gguf-Q4_K_M/Agents-A1.5-Q4_K_M.gguf \
  --mmproj /PATH/TO/Agents-A1.5-gguf-Q4_K_M/Agents-A1.5-mmproj.gguf \
  --alias Agents-A1.5 \
  --jinja 