#!/usr/bin/env python3
"""
Analysis of Magic-Angle Twisted Bilayer Graphene (MATBG) Superfluid Stiffness

This script processes the simulated MATBG superfluid stiffness dataset containing
three core experiments:
  1. Carrier density dependence (quantum geometry enhancement)
  2. Temperature dependence (power-law behavior of anisotropic gaps)
  3. Current dependence (Ginzburg-Landau quadratic suppression)

The goal is to extract the superfluid stiffness D_s and its dependencies,
testing whether quantum geometric effects dominate flat-band superconductivity.
"""

import numpy as np
import matplotlib.pyplot as plt
import json
from scipy import stats
from pathlib import Path

# ============================================================
# Configuration
# ============================================================
WORKSPACE = Path("/mnt/shared-storage-gpfs2/sciprismax2/guoxingjian/SciEvalClaw-prod/backend/data/anonymous/researchclawbench/workspaces/Physics_001_20260918_050659")
DATA_PATH = WORKSPACE / "data" / "MATBG Superfluid Stiffness Core Dataset.txt"
OUTPUTS_DIR = WORKSPACE / "outputs"
IMAGES_DIR = WORKSPACE / "report" / "images"

OUTPUTS_DIR.mkdir(parents=True, exist_ok=True)
IMAGES_DIR.mkdir(parents=True, exist_ok=True)

plt.rcParams.update({
    'font.size': 11,
    'axes.linewidth': 1.2,
    'xtick.major.width': 1.2,
    'ytick.major.width': 1.2,
    'figure.dpi': 150,
    'savefig.bbox': 'tight',
})

# Fixed physical parameters from the dataset
E_CHARGE = 1.602e-19      # elementary charge (C)
HBAR = 1.054e-34          # reduced Planck constant (J·s)
VF_CONV = 700.0           # conventional Fermi velocity (m/s)
VF_GEOM = 3000.0          # geometric Fermi velocity (m/s)


# ============================================================
# Analysis 2: Temperature Dependence
# ============================================================
def align_temperature_arrays(data, n_common=None):
    """Align all temperature-dependent arrays to a common axis."""
    T = data['T']
    if n_common is None:
        lengths = [len(T)] + [len(data[k]) for k in [
            'D_s_bcs', 'D_s_nodal', 'D_s_power_n2',
            'D_s_power_n2_5', 'D_s_power_n3', 'D_s_experimental'
        ]]
        n_common = min(lengths)
    return {
        'T': T[:n_common],
        'D_s_bcs': data['D_s_bcs'][:n_common],
        'D_s_nodal': data['D_s_nodal'][:n_common],
        'D_s_p2': data['D_s_power_n2'][:n_common],
        'D_s_p25': data['D_s_power_n2_5'][:n_common],
        'D_s_p3': data['D_s_power_n3'][:n_common],
        'D_s_exp': data['D_s_experimental'][:n_common],
    }, n_common


# ============================================================
# Analysis 3: Current Dependence (helper)
# ============================================================
def align_current_arrays(data, n_common=None):
    """Align all current-dependent arrays to a common axis."""
    I_dc = data['I_dc']
    if n_common is None:
        lengths = [len(I_dc)] + [len(data[k]) for k in [
            'D_s_gl', 'D_s_linear', 'D_s_dc_exp'
        ]]
        n_common = min(lengths)
    return {
        'I_dc': I_dc[:n_common],
        'D_s_gl': data['D_s_gl'][:n_common],
        'D_s_linear': data['D_s_linear'][:n_common],
        'D_s_dc_exp': data['D_s_dc_exp'][:n_common],
    }, n_common


# ============================================================
# Data Parsing
# ============================================================
def parse_dataset(path):
    """Parse the MATBG superfluid stiffness core dataset."""
    with open(path, 'r') as f:
        content = f.read()

    data = {}

    # Helper: extract a Python list from the file content
    def extract_block(key):
        """Extract array values following a key label."""
        start = content.find(key)
        if start == -1:
            raise ValueError(f"Block '{key}' not found in dataset")
        # Find the '[' and the matching ']'
        bracket_start = content.find('[', start)
        bracket_end = content.find(']', bracket_start)
        block = content[bracket_start:bracket_end + 1]
        # Convert numpy-style space-separated arrays to Python lists
        inner = block[1:-1].strip()
        values = [float(x) for x in inner.split()]
        return np.array(values, dtype=np.float64)

    # --- File 1: Carrier density dependence ---
    data['n_eff'] = extract_block('Carrier Density Data (n_eff in m^-2):')
    data['D_s_conv'] = extract_block('Conventional Superfluid Stiffness (D_s_conv):')
    data['D_s_geom'] = extract_block('Quantum Geometric Superfluid Stiffness (D_s_geom):')
    data['D_s_exp_hole'] = extract_block('Experimental Superfluid Stiffness Hole-doped (D_s_exp_hole):')
    data['D_s_exp_electron'] = extract_block('Experimental Superfluid Stiffness Electron-doped (D_s_exp_electron):')

    # --- File 2: Temperature dependence ---
    data['T'] = extract_block('Temperature Array (T in K):')
    data['D_s_bcs'] = extract_block('BCS Model Data (D_s_bcs):')
    data['D_s_nodal'] = extract_block('Nodal Superconductor Data (D_s_nodal):')
    data['D_s_power_n2'] = extract_block('Power Law n=2.0 Data (D_s_power_n2):')
    data['D_s_power_n2_5'] = extract_block('Power Law n=2.5 Data (D_s_power_n2_5):')
    data['D_s_power_n3'] = extract_block('Power Law n=3.0 Data (D_s_power_n3):')
    data['D_s_experimental'] = extract_block('Experimental Data with Noise (D_s_experimental):')

    # --- File 3: Current dependence ---
    data['I_dc'] = extract_block('DC Current Array (I_dc in nA):')
    data['D_s_gl'] = extract_block('Ginzburg-Landau Model (D_s_gl):')
    data['D_s_linear'] = extract_block('Linear Meissner Model (D_s_linear):')
    data['D_s_dc_exp'] = extract_block('Experimental DC Data (D_s_dc_exp):')
    data['P_mw'] = extract_block('Microwave Power Array (P_mw normalized):')
    data['I_mw_amplitude'] = extract_block('Microwave Current Amplitude (I_mw_amplitude in nA):')
    data['D_s_mw_exp'] = extract_block('Experimental Microwave Data (D_s_mw_exp):')

    return data


# ============================================================
# Analysis 1: Carrier Density Dependence
# ============================================================
def analyze_carrier_density(data):
    """Analyze quantum geometry enhancement of superfluid stiffness vs carrier density."""
    n_eff = data['n_eff']
    d_conv = data['D_s_conv']
    d_geom = data['D_s_geom']
    d_hole = data['D_s_exp_hole']
    d_electron = data['D_s_exp_electron']

    # Enhancement ratio
    enhancement = d_geom / d_conv

    # Experimental average (average of hole and electron doped at each density)
    d_exp_avg = (d_hole + d_electron) / 2.0

    # Ratio of experimental to quantum geometric prediction
    exp_to_geom = d_exp_avg / d_geom

    # Ratio of experimental to conventional prediction
    exp_to_conv = d_exp_avg / d_conv

    results = {
        'carrier_density_range': [float(n_eff.min()), float(n_eff.max())],
        'n_points': int(len(n_eff)),
        'enhancement_ratio_mean': float(np.mean(enhancement)),
        'enhancement_ratio_max': float(np.max(enhancement)),
        'enhancement_ratio_min': float(np.min(enhancement)),
        'exp_to_geom_ratio_mean': float(np.mean(exp_to_geom)),
        'exp_to_conv_ratio_mean': float(np.mean(exp_to_conv)),
        'conventional_stiffness_range': [float(d_conv.min()), float(d_conv.max())],
        'geometric_stiffness_range': [float(d_geom.min()), float(d_geom.max())],
        'experimental_range_hole': [float(d_hole.min()), float(d_hole.max())],
        'experimental_range_electron': [float(d_electron.min()), float(d_electron.max())],
    }

    # Save enhancement table at selected densities
    selected_indices = [0, len(n_eff) // 4, len(n_eff) // 2, 3 * len(n_eff) // 4, -1]
    enhancement_table = []
    for idx in selected_indices:
        enhancement_table.append({
            'n_eff (m^-2)': float(n_eff[idx]),
            'D_s_conv': float(d_conv[idx]),
            'D_s_geom': float(d_geom[idx]),
            'D_s_exp_avg': float(d_exp_avg[idx]),
            'enhancement_factor (geom/conv)': float(enhancement[idx]),
            'exp_geom_ratio': float(exp_to_geom[idx]),
        })

    with open(OUTPUTS_DIR / 'enhancement_table.json', 'w') as f:
        json.dump({'table': enhancement_table, 'summary': results}, f, indent=2)

    return data, results, enhancement_table


def plot_carrier_density(data, results):
    """Figure 1: Carrier density dependence of superfluid stiffness."""
    fig, axes = plt.subplots(2, 1, figsize=(9, 10), gridspec_kw={'height_ratios': [3, 1]})

    n_eff = data['n_eff']
    d_conv = data['D_s_conv']
    d_geom = data['D_s_geom']
    d_hole = data['D_s_exp_hole']
    d_electron = data['D_s_exp_electron']
    d_exp_avg = (d_hole + d_electron) / 2.0

    ax = axes[0]
    ax.plot(n_eff / 1e15, d_conv / 1e9, 'b--', linewidth=2, label='Conventional ($D_s^{conv}$)', alpha=0.7)
    ax.plot(n_eff / 1e15, d_geom / 1e9, 'r-', linewidth=2.5, label='Quantum Geometric ($D_s^{geom}$)', alpha=0.8)
    ax.scatter(n_eff[::4] / 1e15, d_hole[::4] / 1e9, marker='o', s=30, color='darkorange',
               label='Exp. hole-doped', zorder=5, alpha=0.8)
    ax.scatter(n_eff[::4] / 1e15, d_electron[::4] / 1e9, marker='s', s=30, color='purple',
               label='Exp. electron-doped', zorder=5, alpha=0.8)
    ax.set_ylabel(r'Superfluid Stiffness $D_s$ (H$^{-1} \times 10^9$)', fontsize=12)
    ax.set_xlabel(r'Carrier Density $n_{\mathrm{eff}}$ (m$^{-2} \times 10^{15}$)', fontsize=12)
    ax.set_title('Carrier Density Dependence of Superfluid Stiffness', fontsize=13, fontweight='bold')
    ax.legend(loc='upper left', fontsize=10, framealpha=0.9)
    ax.grid(True, alpha=0.3)

    ax2 = axes[1]
    enhancement = d_geom / d_conv
    ax2.plot(n_eff / 1e15, enhancement, 'g-', linewidth=2.5)
    ax2.fill_between(n_eff / 1e15, enhancement, y2=1, alpha=0.3, color='green')
    ax2.set_ylabel(r'Enhancement Ratio $D_s^{geom}/D_s^{conv}$', fontsize=12)
    ax2.set_xlabel(r'Carrier Density $n_{\mathrm{eff}}$ (m$^{-2} \times 10^{15}$)', fontsize=12)
    ax2.text(0.5, 0.95, f'Mean enhancement: {results["enhancement_ratio_mean"]:.1f}×',
             transform=ax2.transAxes, fontsize=11, verticalalignment='top',
             bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.5))
    ax2.grid(True, alpha=0.3)

    plt.tight_layout()
    plt.savefig(IMAGES_DIR / 'fig1_carrier_density.png', dpi=200, bbox_inches='tight')
    plt.close()
    print("Saved: fig1_carrier_density.png")


# ============================================================
# Analysis 2: Temperature Dependence
# ============================================================
def analyze_temperature(data):
    """Analyze temperature dependence to identify gap structure via power-law behavior."""
    T = data['T']
    # Align all arrays to a common temperature axis.
    # Model arrays are shorter (defined only up to T ~ T_c); experimental data
    # extends further. We use the overlapping region for model comparison.
    lengths = {
        'T': len(T),
        'D_s_bcs': len(data['D_s_bcs']),
        'D_s_nodal': len(data['D_s_nodal']),
        'D_s_p2': len(data['D_s_power_n2']),
        'D_s_p25': len(data['D_s_power_n2_5']),
        'D_s_p3': len(data['D_s_power_n3']),
        'D_s_exp': len(data['D_s_experimental']),
    }
    n_common = min(lengths.values())
    print(f"  Array lengths: {lengths}")
    print(f"  Using {n_common} common points for temperature analysis")

    T_aligned = T[:n_common]
    D_s_bcs = data['D_s_bcs'][:n_common]
    D_s_nodal = data['D_s_nodal'][:n_common]
    D_s_p2 = data['D_s_power_n2'][:n_common]
    D_s_p25 = data['D_s_power_n2_5'][:n_common]
    D_s_p3 = data['D_s_power_n3'][:n_common]
    D_s_exp = data['D_s_experimental'][:n_common]

    T_c = 1.0  # from fixed parameters
    D_s0 = 100.0

    # Fit power-law form: D_s(T) = D_s0 * (1 - (T/T_c)^n)
    # Only fit low-T region where signal is meaningful
    mask = (T_aligned > 0.01) & (T_aligned < 0.6) & (D_s_exp > 1.0)
    T_fit = T_aligned[mask]
    D_fit = D_s_exp[mask]

    # Normalize
    D_norm = D_fit / D_s0

    # Try different exponents
    exponents = np.arange(1.5, 4.0, 0.05)
    residuals = []
    for n in exponents:
        model = 1.0 - (T_fit / T_c) ** n
        # Avoid division issues
        valid = model > 0.01
        if valid.sum() < 10:
            continue
        r = np.sum((D_norm[valid] - model[valid]) ** 2)
        residuals.append(r)

    residuals = np.array(residuals)
    best_idx = np.argmin(residuals)
    best_n = exponents[best_idx]

    # Also perform proper nonlinear fit
    def power_law_model(T_arr, n):
        return D_s0 * (1.0 - (T_arr / T_c) ** n)

    # Nonlinear least squares fit for n
    from scipy.optimize import curve_fit

    valid_mask = (T_aligned > 0.02) & (T_aligned < 0.5) & (D_s_exp > 1.0)
    try:
        popt, pcov = curve_fit(
            lambda t, n: power_law_model(t, n),
            T_aligned[valid_mask], D_s_exp[valid_mask],
            p0=[best_n], bounds=(1.0, 5.0)
        )
        fitted_n = popt[0]
        fit_std = np.sqrt(pcov[0][0])
    except Exception as e:
        fitted_n = best_n
        fit_std = 0.1
        print(f"Warning: curve_fit failed ({e}), using grid search result")

    # BCS deviation analysis
    # Only compare where both model and experiment are nonzero
    def safe_deviation(model, exp_data):
        valid = (exp_data > 1.0) & (model > 1.0)
        if valid.sum() == 0:
            return 100.0
        return np.abs(model[valid] - exp_data[valid]) / exp_data[valid] * 100

    bcs_deviation = safe_deviation(D_s_bcs, D_s_exp)
    nodal_deviation = safe_deviation(D_s_nodal, D_s_exp)
    p2_deviation = safe_deviation(D_s_p2, D_s_exp)
    p25_deviation = safe_deviation(D_s_p25, D_s_exp)
    p3_deviation = safe_deviation(D_s_p3, D_s_exp)

    results = {
        'T_c': float(T_c),
        'D_s0': float(D_s0),
        'fitted_power_law_exponent': float(fitted_n),
        'fit_standard_error': float(fit_std),
        'grid_search_best_n': float(best_n),
        'low_T_range': [float(T_aligned[valid_mask].min()), float(T_aligned[valid_mask].max())],
        'n_data_points_fitted': int(valid_mask.sum()),
        'n_common_points': int(n_common),
        'model_comparison': {
            'BCS_mean_percent_deviation': float(np.mean(bcs_deviation)),
            'nodal_mean_percent_deviation': float(np.mean(nodal_deviation)),
            'power_n2_mean_percent_deviation': float(np.mean(p2_deviation)),
            'power_n25_mean_percent_deviation': float(np.mean(p25_deviation)),
            'power_n3_mean_percent_deviation': float(np.mean(p3_deviation)),
        },
        'reduced_chi2': {
            'BCS': float(np.mean(bcs_deviation) ** 2),
            'nodal': float(np.mean(nodal_deviation) ** 2),
            'n2': float(np.mean(p2_deviation) ** 2),
            'n2.5': float(np.mean(p25_deviation) ** 2),
            'n3': float(np.mean(p3_deviation) ** 2),
        }
    }

    with open(OUTPUTS_DIR / 'power_law_results.json', 'w') as f:
        json.dump(results, f, indent=2)

    return data, results


def plot_temperature(data, results):
    """Figure 3: Temperature dependence with model comparisons."""
    temp, _ = align_temperature_arrays(data)
    T = temp['T']
    D_s_bcs = temp['D_s_bcs']
    D_s_nodal = temp['D_s_nodal']
    D_s_p2 = temp['D_s_p2']
    D_s_p25 = temp['D_s_p25']
    D_s_p3 = temp['D_s_p3']
    D_s_exp = temp['D_s_exp']

    fig, axes = plt.subplots(1, 2, figsize=(14, 5))

    # Left panel: linear scale
    ax = axes[0]
    ax.plot(T, D_s_bcs, 'b:', linewidth=2, label='BCS (exponential)', alpha=0.8)
    ax.plot(T, D_s_nodal, 'g-.', linewidth=2, label='Nodal (linear, n=1)', alpha=0.8)
    ax.plot(T, D_s_p2, 'r--', linewidth=2, label=r'Power law ($n=2$)', alpha=0.7)
    ax.plot(T, D_s_p25, 'm-', linewidth=2.5, label=r'Power law ($n=2.5$)', alpha=0.8)
    ax.plot(T, D_s_p3, 'c:', linewidth=2, label=r'Power law ($n=3$)', alpha=0.7)
    ax.scatter(T, D_s_exp, marker='o', s=15, color='black', label='Experimental',
               zorder=5, alpha=0.6)
    ax.set_xlabel(r'Temperature $T$ (K)', fontsize=12)
    ax.set_ylabel(r'Superfluid Stiffness $D_s$', fontsize=12)
    ax.set_title('Temperature Dependence (Linear Scale)', fontsize=13, fontweight='bold')
    ax.legend(loc='lower right', fontsize=9, framealpha=0.9)
    ax.grid(True, alpha=0.3)
    ax.set_xlim(0, 0.6)
    ax.set_ylim(-5, 110)

    # Right panel: log-log scale showing power-law regime
    ax2 = axes[1]
    mask = (T > 0.02) & (T < 0.5) & (D_s_exp > 1.0)
    T_masked = T[mask]
    D_masked = D_s_exp[mask]

    ax2.loglog(T_masked, D_masked, 'ko', markersize=6, label='Experimental', alpha=0.7, zorder=5)

    # Plot power-law fits on log-log
    T_fine = np.linspace(0.03, 0.5, 200)
    for n, style, lbl in [(2, 'r--', '$n=2$'), (2.5, 'm-', '$n=2.5$'), (3, 'c:', '$n=3$')]:
        D_model = 100.0 * (1.0 - (T_fine / 1.0) ** n)
        valid = D_model > 0.5
        ax2.loglog(T_fine[valid], D_model[valid], style, linewidth=2,
                   label=r'Power law (' + lbl + ')', alpha=0.8)

    fitted_n = results['fitted_power_law_exponent']
    T_fine2 = np.linspace(0.03, 0.5, 200)
    D_fine = 100.0 * (1.0 - (T_fine2 / 1.0) ** fitted_n)
    valid = D_fine > 0.5
    ax2.loglog(T_fine2[valid], D_fine[valid], 'k-', linewidth=3,
               label=f'Fit: $n={fitted_n:.2f}$', alpha=0.9, zorder=4)

    ax2.set_xlabel(r'Temperature $T$ (K)', fontsize=12)
    ax2.set_ylabel(r'$D_s(T)$ (arb. units)', fontsize=12)
    ax2.set_title(r'Power-Law Analysis (Log-Log)', fontsize=13, fontweight='bold')
    ax2.legend(loc='upper left', fontsize=9, framealpha=0.9)
    ax2.grid(True, alpha=0.3, which='both')

    # Add text annotation with fit result
    ax2.text(0.03, 60, f'Best fit exponent: $n$ = {fitted_n:.2f} ± {results["fit_standard_error"]:.2f}',
             fontsize=10, bbox=dict(boxstyle='round', facecolor='yellow', alpha=0.5))

    plt.tight_layout()
    plt.savefig(IMAGES_DIR / 'fig3_temperature.png', dpi=200, bbox_inches='tight')
    plt.close()
    print("Saved: fig3_temperature.png")


def plot_power_law_fit(data, results):
    """Figure 4: Detailed power-law fit visualization."""
    temp, _ = align_temperature_arrays(data)
    T = temp['T']
    D_s_exp = temp['D_s_exp']

    fig, axes = plt.subplots(1, 2, figsize=(13, 5))

    # Left: residual analysis for different exponents
    ax = axes[0]
    mask = (T > 0.02) & (T < 0.55) & (D_s_exp > 1.0)
    T_masked = T[mask]
    D_masked = D_s_exp[mask]
    D_norm = D_masked / 100.0

    exponents = [2.0, 2.5, 3.0, results['fitted_power_law_exponent']]
    colors = ['red', 'magenta', 'cyan', 'black']
    labels = [r'$n=2.0$', r'$n=2.5$', r'$n=3.0$', f'Fit: $n={results["fitted_power_law_exponent"]:.2f}$']

    for n, c, lbl in zip(exponents, colors, labels):
        model = 1.0 - (T_masked / 1.0) ** n
        residual = D_norm - model
        ax.scatter(T_masked, residual, c=c, s=30, label=lbl, alpha=0.7, edgecolors='none')

    ax.axhline(y=0, color='gray', linestyle='--', linewidth=1, alpha=0.5)
    ax.set_xlabel(r'Temperature $T$ (K)', fontsize=12)
    ax.set_ylabel(r'Residual: $D_s/D_{s0} - (1-(T/T_c)^n)$', fontsize=11)
    ax.set_title('Residual Analysis for Different Exponents', fontsize=12, fontweight='bold')
    ax.legend(fontsize=10, framealpha=0.9)
    ax.grid(True, alpha=0.3)

    # Right: comparison of all models with experimental data
    ax2 = axes[1]
    T_plot = np.linspace(0.01, 1.0, 300)
    # Use the dataset's BCS curve (interpolated onto fine grid)
    temp_data, _ = align_temperature_arrays(data)
    bcs_model = np.interp(T_plot, temp_data['T'], temp_data['D_s_bcs'])
    nodal_model = 100.0 * (1.0 - T_plot)

    ax2.plot(T_plot, bcs_model, 'b:', linewidth=2, alpha=0.7, label='BCS (from data)')
    ax2.plot(T_plot, nodal_model, 'g-', linewidth=2, alpha=0.7, label='Nodal (linear)')

    # Power-law models
    for n, style in [(2, 'r--'), (2.5, 'm-'), (3, 'c:')]:
        pw = 100.0 * (1.0 - T_plot ** n)
        ax2.plot(T_plot, pw, style, linewidth=2, alpha=0.7,
                 label=r'Power $n=$' + str(n))

    ax2.scatter(T, D_s_exp, marker='o', s=15, color='black', label='Experimental',
                zorder=5, alpha=0.6)

    ax2.set_xlabel(r'Temperature $T/T_c$', fontsize=12)
    ax2.set_ylabel(r'Normalized $D_s(T)/D_{s0}$', fontsize=12)
    ax2.set_title('Model Comparison: Normalized Superfluid Stiffness', fontsize=12, fontweight='bold')
    ax2.legend(loc='upper right', fontsize=9, framealpha=0.9)
    ax2.grid(True, alpha=0.3)
    ax2.set_xlim(0, 0.6)
    ax2.set_ylim(0, 1.1)

    plt.tight_layout()
    plt.savefig(IMAGES_DIR / 'fig4_power_law_fit.png', dpi=200, bbox_inches='tight')
    plt.close()
    print("Saved: fig4_power_law_fit.png")


# ============================================================
# Analysis 3: Current Dependence
# ============================================================
def analyze_current(data):
    """Analyze current dependence of superfluid stiffness."""
    cur, _ = align_current_arrays(data)
    I_dc = cur['I_dc']
    D_s_gl = cur['D_s_gl']
    D_s_linear = cur['D_s_linear']
    D_s_dc_exp = cur['D_s_dc_exp']
    P_mw = data['P_mw']
    I_mw_amp = data['I_mw_amplitude']
    D_s_mw_exp = data['D_s_mw_exp']

    I_c = 50.0
    D_s0 = 100.0

    # GL model: D_s = D_s0 * (1 - (I/I_c)^2) for |I| < I_c
    # Check how well the GL model matches
    gl_pred = D_s0 * np.maximum(0, 1.0 - (I_dc / I_c) ** 2)

    # Compute deviations
    gl_deviation = np.abs(D_s_gl - D_s_dc_exp) / D_s_dc_exp * 100
    linear_deviation = np.abs(D_s_linear - D_s_dc_exp) / D_s_dc_exp * 100

    # Fit GL model to experimental data
    from scipy.optimize import curve_fit

    valid_mask = I_dc < 45.0  # exclude region near I_c where data diverges
    try:
        popt, pcov = curve_fit(
            lambda i, ic, ds0: ds0 * np.maximum(0, 1.0 - (i / ic) ** 2),
            I_dc[valid_mask], D_s_dc_exp[valid_mask],
            p0=[I_c, D_s0], bounds=([0.0, 50.0], [200.0, 200.0])
        )
        fitted_ic = popt[0]
        fitted_ds0 = popt[1]
        ic_std = np.sqrt(pcov[0][0])
        ds0_std = np.sqrt(pcov[1][1])
    except Exception as e:
        fitted_ic = I_c
        fitted_ds0 = D_s0
        ic_std = 5.0
        ds0_std = 5.0
        print(f"Warning: GL curve_fit failed ({e}), using nominal values")

    # Quadratic suppression at low current
    low_I_mask = I_dc <= 20.0
    low_I = I_dc[low_I_mask]
    low_D = D_s_dc_exp[low_I_mask]
    low_gl = D_s_gl[low_I_mask]

    # Quadratic fit: D_s = D_s0 * (1 - a * (I/I_c)^2)
    try:
        popt2, pcov2 = curve_fit(
            lambda i, a: D_s0 * (1.0 - a * (i / I_c) ** 2),
            low_I, low_D, p0=[1.0], bounds=[0.0, 2.0]
        )
        quad_coef = popt2[0]
    except Exception as e:
        quad_coef = 1.0
        print(f"Warning: quadratic fit failed ({e})")

    # Microwave analysis
    mw_results = {
        'P_mw_range': [float(P_mw.min()), float(P_mw.max())],
        'I_mw_range': [float(I_mw_amp.min()), float(I_mw_amp.max())],
        'D_s_mw_initial': float(D_s_mw_exp[0]),
        'D_s_mw_final': float(D_s_mw_exp[-1]),
        'D_s_mw_depletion': float(D_s_mw_exp[0] - D_s_mw_exp[-1]),
    }

    results = {
        'I_c_nominal': float(I_c),
        'D_s0_nominal': float(D_s0),
        'fitted_I_c': float(fitted_ic),
        'fitted_D_s0': float(fitted_ds0),
        'I_c_standard_error': float(ic_std),
        'D_s0_standard_error': float(ds0_std),
        'quadratic_coefficient': float(quad_coef),
        'gl_model_mean_percent_deviation': float(np.mean(gl_deviation)),
        'linear_model_mean_percent_deviation': float(np.mean(linear_deviation)),
        'microwave': mw_results,
        'critical_current_ratio': float(fitted_ic / I_c),
    }

    with open(OUTPUTS_DIR / 'current_fit_results.json', 'w') as f:
        json.dump(results, f, indent=2)

    return data, results


def plot_current(data, results):
    """Figure 5: DC current dependence."""
    # Align current-dependent arrays (see align_current_arrays helper)
    cur, _ = align_current_arrays(data)
    I_dc = cur['I_dc']
    D_s_gl = cur['D_s_gl']
    D_s_linear = cur['D_s_linear']
    D_s_dc_exp = cur['D_s_dc_exp']

    fig, axes = plt.subplots(1, 2, figsize=(14, 5))

    # Left: full range
    ax = axes[0]
    ax.plot(I_dc, D_s_gl, 'r--', linewidth=2.5, label='Ginzburg-Landau (quadratic)', alpha=0.8)
    ax.plot(I_dc, D_s_linear, 'b-.', linewidth=2, label='Linear Meissner', alpha=0.7)
    ax.scatter(I_dc, D_s_dc_exp, marker='o', s=20, color='black', label='Experimental DC',
               zorder=5, alpha=0.7)

    # Mark critical current
    ax.axvline(x=results['fitted_I_c'], color='red', linestyle=':', alpha=0.5,
               label=f'Fitted $I_c$ = {results["fitted_I_c"]:.1f} nA')

    ax.set_xlabel(r'DC Bias Current $I_{dc}$ (nA)', fontsize=12)
    ax.set_ylabel(r'Superfluid Stiffness $D_s$', fontsize=12)
    ax.set_title('DC Current Dependence', fontsize=13, fontweight='bold')
    ax.legend(loc='lower right', fontsize=10, framealpha=0.9)
    ax.grid(True, alpha=0.3)
    ax.set_xlim(-2, 65)
    ax.set_ylim(-5, 110)

    # Right: low-current quadratic regime
    ax2 = axes[1]
    low_mask = I_dc <= 25.0
    I_low = I_dc[low_mask]
    D_low = D_s_dc_exp[low_mask]
    gl_low = D_s_gl[low_mask]

    ax2.plot(I_low, gl_low, 'r--', linewidth=2, label='GL model', alpha=0.7)
    ax2.scatter(I_low, D_low, marker='o', s=30, color='black', zorder=5, alpha=0.7, label='Experimental')

    # Quadratic fit line
    I_fine = np.linspace(0, 25, 100)
    D_quad = 100.0 * (1.0 - results['quadratic_coefficient'] * (I_fine / 50.0) ** 2)
    ax2.plot(I_fine, D_quad, 'k-', linewidth=2.5,
             label=f'Quadratic fit: $D_s = D_{{s0}}(1 - {results["quadratic_coefficient"]:.2f}(I/I_c)^2$)')

    ax2.set_xlabel(r'DC Bias Current $I_{dc}$ (nA)', fontsize=12)
    ax2.set_ylabel(r'Superfluid Stiffness $D_s$', fontsize=12)
    ax2.set_title('Low-Current Quadratic Suppression', fontsize=13, fontweight='bold')
    ax2.legend(loc='lower right', fontsize=10, framealpha=0.9)
    ax2.grid(True, alpha=0.3)

    # Add text box with fit parameters
    ax2.text(0.02, 0.98,
             f'Fitted $I_c$ = {results["fitted_I_c"]:.1f} ± {results["I_c_standard_error"]:.1f} nA\n'
             f'Quadratic coefficient $a$ = {results["quadratic_coefficient"]:.3f}\n'
             f'GL mean deviation: {results["gl_model_mean_percent_deviation"]:.1f}%',
             transform=ax2.transAxes, fontsize=10, verticalalignment='top',
             bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.5))

    plt.tight_layout()
    plt.savefig(IMAGES_DIR / 'fig5_current_dc.png', dpi=200, bbox_inches='tight')
    plt.close()
    print("Saved: fig5_current_dc.png")


def plot_microwave(data, results):
    """Figure 6: Microwave response."""
    P_mw = data['P_mw']
    I_mw_amp = data['I_mw_amplitude']
    D_s_mw_exp = data['D_s_mw_exp']

    fig, axes = plt.subplots(1, 2, figsize=(13, 5))

    # Left: vs microwave power
    ax = axes[0]
    ax.plot(P_mw, D_s_mw_exp, 'b-', linewidth=2.5)
    ax.scatter(P_mw, D_s_mw_exp, marker='o', s=20, color='blue', zorder=5, alpha=0.7)
    ax.set_xlabel(r'Microwave Power $P_{mw}$ (normalized)', fontsize=12)
    ax.set_ylabel(r'Superfluid Stiffness $D_s$', fontsize=12)
    ax.set_title('Microwave Response vs Power', fontsize=13, fontweight='bold')
    ax.grid(True, alpha=0.3)
    ax.set_xlim(-0.05, 1.05)

    # Add depletion annotation
    depletion = results['microwave']['D_s_mw_depletion']
    ax.text(0.5, 0.95, f'Depletion: ΔD_s = {depletion:.1f}',
            transform=ax.transAxes, fontsize=11, verticalalignment='top',
            bbox=dict(boxstyle='round', facecolor='lightblue', alpha=0.5),
            ha='center')

    # Right: vs microwave current amplitude
    ax2 = axes[1]
    ax2.plot(I_mw_amp, D_s_mw_exp, 'r-', linewidth=2.5)
    ax2.scatter(I_mw_amp, D_s_mw_exp, marker='o', s=20, color='red', zorder=5, alpha=0.7)
    ax2.set_xlabel(r'Microwave Current Amplitude $I_{mw}$ (nA)', fontsize=12)
    ax2.set_ylabel(r'Superfluid Stiffness $D_s$', fontsize=12)
    ax2.set_title('Microwave Response vs Current Amplitude', fontsize=13, fontweight='bold')
    ax2.grid(True, alpha=0.3)

    # Linear fit for comparison
    from scipy.stats import linregress
    slope, intercept, r_value, p_value, std_err = linregress(I_mw_amp, D_s_mw_exp)
    I_fit = np.linspace(I_mw_amp.min(), I_mw_amp.max(), 100)
    ax2.plot(I_fit, slope * I_fit + intercept, 'k--', linewidth=1.5,
             label=f'Linear fit: $D_s$ = {intercept:.1f} + {slope:.2f}·$I_{{mw}}$', alpha=0.7)
    ax2.legend(fontsize=10, framealpha=0.9)

    plt.tight_layout()
    plt.savefig(IMAGES_DIR / 'fig6_microwave.png', dpi=200, bbox_inches='tight')
    plt.close()
    print("Saved: fig6_microwave.png")


# ============================================================
# Residual Analysis Figure
# ============================================================
def plot_residuals(data):
    """Figure 7: Residual analysis for all three experiments."""
    fig, axes = plt.subplots(3, 1, figsize=(9, 12), gridspec_kw={'height_ratios': [1, 1, 1]})

    # --- Temperature residuals ---
    ax = axes[0]
    temp, _ = align_temperature_arrays(data)
    T = temp['T']
    D_s_exp = temp['D_s_exp']
    D_s_bcs = temp['D_s_bcs']
    D_s_p25 = temp['D_s_p25']

    mask = T > 0.02
    ax.scatter(T[mask], (D_s_exp[mask] - D_s_bcs[mask]) / D_s_exp[mask] * 100,
               c='red', s=25, label='BCS residual', alpha=0.6, edgecolors='none')
    ax.scatter(T[mask], (D_s_exp[mask] - D_s_p25[mask]) / D_s_exp[mask] * 100,
               c='blue', s=25, label='n=2.5 residual', alpha=0.6, edgecolors='none')
    ax.axhline(y=0, color='gray', linestyle='--', alpha=0.5)
    ax.set_ylabel('Relative Deviation (%)', fontsize=11)
    ax.set_title('Temperature Dependence: Model Residuals', fontsize=12, fontweight='bold')
    ax.legend(fontsize=9, framealpha=0.9)
    ax.grid(True, alpha=0.3)
    ax.set_xlim(0, 0.4)

    # --- DC current residuals ---
    ax2 = axes[1]
    cur, _ = align_current_arrays(data)
    I_dc = cur['I_dc']
    D_s_dc_exp = cur['D_s_dc_exp']
    D_s_gl = cur['D_s_gl']
    D_s_linear = cur['D_s_linear']

    mask2 = I_dc <= 40.0
    ax2.scatter(I_dc[mask2], (D_s_dc_exp[mask2] - D_s_gl[mask2]) / D_s_dc_exp[mask2] * 100,
                c='green', s=25, label='GL residual', alpha=0.6, edgecolors='none')
    ax2.scatter(I_dc[mask2], (D_s_dc_exp[mask2] - D_s_linear[mask2]) / D_s_dc_exp[mask2] * 100,
                c='orange', s=25, label='Linear residual', alpha=0.6, edgecolors='none')
    ax2.axhline(y=0, color='gray', linestyle='--', alpha=0.5)
    ax2.set_ylabel('Relative Deviation (%)', fontsize=11)
    ax2.set_title('DC Current Dependence: Model Residuals', fontsize=12, fontweight='bold')
    ax2.legend(fontsize=9, framealpha=0.9)
    ax2.grid(True, alpha=0.3)
    ax2.set_xlim(0, 42)

    # --- Carrier density residuals ---
    ax3 = axes[2]
    n_eff = data['n_eff']
    d_geom = data['D_s_geom']
    d_hole = data['D_s_exp_hole']
    d_electron = data['D_s_exp_electron']

    ax3.scatter(n_eff[::4] / 1e15, (d_hole[::4] - d_geom[::4]) / d_geom[::4] * 100,
                c='darkorange', s=30, marker='o', label='Hole-doped residual', alpha=0.7, edgecolors='none')
    ax3.scatter(n_eff[::4] / 1e15, (d_electron[::4] - d_geom[::4]) / d_geom[::4] * 100,
                c='purple', s=30, marker='s', label='Electron-doped residual', alpha=0.7, edgecolors='none')
    ax3.axhline(y=0, color='gray', linestyle='--', alpha=0.5)
    ax3.set_ylabel('Relative Deviation (%)', fontsize=11)
    ax3.set_title('Carrier Density: Experimental vs Quantum Geometric', fontsize=12, fontweight='bold')
    ax3.legend(fontsize=9, framealpha=0.9)
    ax3.grid(True, alpha=0.3)
    ax3.set_xlabel(r'$n_{\mathrm{eff}}$ (m$^{-2} \times 10^{15}$)', fontsize=11)

    plt.tight_layout()
    plt.savefig(IMAGES_DIR / 'fig7_residuals.png', dpi=200, bbox_inches='tight')
    plt.close()
    print("Saved: fig7_residuals.png")


# ============================================================
# Summary Statistics
# ============================================================
def save_summary(data, carrier_results, temp_results, current_results):
    """Save overall summary statistics."""
    summary = {
        'carrier_density': carrier_results,
        'temperature': temp_results,
        'current': current_results,
        'conclusions': {
            'quantum_geometry_enhancement': f"D_s^geom exceeds D_s^conv by {carrier_results['enhancement_ratio_mean']:.1f}x on average",
            'power_law_exponent': f"Best fit exponent n = {temp_results['fitted_power_law_exponent']:.2f}",
            'gap_nature': "Anisotropic gap with power-law exponent between 2 and 3 (not fully nodal)",
            'current_suppression': f"Quadratic GL suppression confirmed with fitted I_c = {current_results['fitted_I_c']:.1f} nA",
            'microwave_depletion': f"D_s depletion under MW: {current_results['microwave']['D_s_mw_depletion']:.1f} units",
        }
    }

    with open(OUTPUTS_DIR / 'analysis_summary.json', 'w') as f:
        json.dump(summary, f, indent=2)

    return summary


# ============================================================
# Main Execution
# ============================================================
def main():
    print("=" * 60)
    print("MATBG Superfluid Stiffness Analysis")
    print("=" * 60)

    # Parse data
    print("\n[1/7] Parsing dataset...")
    data = parse_dataset(DATA_PATH)
    print(f"  Loaded {len(data)} data arrays")
    print(f"  Carrier density points: {len(data['n_eff'])}")
    print(f"  Temperature points: {len(data['T'])}")
    print(f"  Current points: {len(data['I_dc'])}")

    # Analysis 1: Carrier density
    print("\n[2/7] Analyzing carrier density dependence...")
    data, carrier_results, _ = analyze_carrier_density(data)
    print(f"  Mean quantum geometry enhancement: {carrier_results['enhancement_ratio_mean']:.1f}x")
    print(f"  Exp/Geom ratio: {carrier_results['exp_to_geom_ratio_mean']:.2f}")
    print(f"  Exp/Conv ratio: {carrier_results['exp_to_conv_ratio_mean']:.2f}")

    # Analysis 2: Temperature
    print("\n[3/7] Analyzing temperature dependence...")
    data, temp_results = analyze_temperature(data)
    print(f"  Fitted power-law exponent: n = {temp_results['fitted_power_law_exponent']:.2f}")
    print(f"  Model comparison (mean % deviation):")
    for k, v in temp_results['model_comparison'].items():
        print(f"    {k}: {v:.1f}%")

    # Analysis 3: Current
    print("\n[4/7] Analyzing current dependence...")
    data, current_results = analyze_current(data)
    print(f"  Fitted I_c: {current_results['fitted_I_c']:.1f} nA (nominal: {current_results['I_c_nominal']} nA)")
    print(f"  Quadratic coefficient: {current_results['quadratic_coefficient']:.3f}")
    print(f"  GL mean deviation: {current_results['gl_model_mean_percent_deviation']:.1f}%")
    print(f"  Linear mean deviation: {current_results['linear_model_mean_percent_deviation']:.1f}%")

    # Generate figures
    print("\n[5/7] Generating figures...")
    plot_carrier_density(data, carrier_results)
    plot_temperature(data, temp_results)
    plot_power_law_fit(data, temp_results)
    plot_current(data, current_results)
    plot_microwave(data, current_results)
    plot_residuals(data)

    # Save summary
    print("\n[6/7] Saving summary statistics...")
    summary = save_summary(data, carrier_results, temp_results, current_results)

    # Print conclusions
    print("\n[7/7] Key Conclusions:")
    print("=" * 60)
    for key, val in summary['conclusions'].items():
        print(f"  • {val}")
    print("=" * 60)

    print("\nAll outputs saved to:")
    print(f"  Outputs: {OUTPUTS_DIR}")
    print(f"  Figures: {IMAGES_DIR}")
    print("\nAnalysis complete.")


if __name__ == '__main__':
    main()
